export default {
  all: 'Todas',
  article: 'Artículos',
  tag: 'Etiquetas',
  category: 'Categorías',
  friendLink: 'Páginas amigas',
  timeLine: 'Cronología',
  timeLineMsg: 'Regreso al futuro, o al pasado 🚀'
}
