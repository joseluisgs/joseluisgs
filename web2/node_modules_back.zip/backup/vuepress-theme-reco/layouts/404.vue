<template>
  <section class="theme-container" v-if="!noFoundPageByTencent">
    <article class="content">
      <!-- <h1>404</h1> -->
      <!-- <blockquote>{{ getMsg() }}</blockquote> -->
      <router-link to="/"><img src="/img/404.gif"></router-link>
      <router-link to="/">Volver a inicio.</router-link>
    </article>
  </section>
</template>

<script>
const msgs = [
  `There's nothing here.`,
  `How did we get here?`,
  `That's a Four-Oh-Four.`,
  `Looks like we've got some broken links.`
];

export default {
  computed: {
    noFoundPageByTencent() {
      return this.$themeConfig.noFoundPageByTencent !== false;
    }
  },
  mounted() {
    if (this.noFoundPageByTencent) {
      const dom = document.createElement("script");
      dom.setAttribute("homePageName", "回到首页");
      dom.setAttribute("homePageUrl", this.$site.base);
      dom.setAttribute(
        "src",
        "//qzonestyle.gtimg.cn/qzone/hybrid/app/404/search_children.js"
      );

      document.body.append(dom);
    }
  },
  methods: {
    getMsg() {
      return msgs[Math.floor(Math.random() * msgs.length)];
    }
  }
};
</script>

<style src="../styles/theme.styl" lang="stylus"></style>

<style lang="stylus">
.content {
  margin: 4rem auto 0;
  max-width: 800px;
  padding: 0 2rem;
}

.mod_404 {
  .desc {
    .desc_link {
      display: inline-block;
      // margin: 20px 0
      background: #424242 !important;
      color: #ffffff;
      padding: 6px 20px !important;
      text-decoration: none !important;
      border-radius: 4px;
    }
  }
}

@media screen and (max-width: 720px) {
  .mod_404 {
    .desc {
      margin: 50px 0;
    }

    .wrapper {
      margin: 0 !important;
      padding-top: 20px;
    }
  }
}
</style>

